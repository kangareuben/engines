#include "MainGame.h"
#include "iostream"
#include <boost/thread/thread.hpp>

int main(int argc, char **argv)
{
MainGame mainGame;
/*	boost::thread thrd1(&fn1);
boost::thread thrd2(&fn2);
boost::thread thrd3(&fn3);
thrd1.join();
thrd2.join();
thrd3.join();
*/
mainGame.run();

return 0;
}